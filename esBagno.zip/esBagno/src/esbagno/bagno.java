package esbagno;

import java.util.logging.Level;
import java.util.logging.Logger;


public class bagno 
{
    
    synchronized void stampaUomo()
        {
        
        System.out.println("un uomo è entrato");
        
        try 
    {
            
            Thread.sleep(5000);
            
    } 
        catch (InterruptedException ex) 
      {
          
            Logger.getLogger(bagno.class.getName()).log(Level.SEVERE, null, ex);
      }
        
        System.out.println("uomo è uscito");
        
        }
}
