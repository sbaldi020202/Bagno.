package esbagno;

import java.util.logging.Level;
import java.util.logging.Logger;


public class bagno2  
     {
    
     synchronized void stampaDonna()
     {
        
         System.out.println("una donna è entrata");
         
         try 
     {
            
         Thread.sleep(5000);
     } 
         catch (InterruptedException ex) 
     {
            
             Logger.getLogger(bagno.class.getName()).log(Level.SEVERE, null, ex);
     }
        
         System.out.println("donna è uscita");
    
     }
}
