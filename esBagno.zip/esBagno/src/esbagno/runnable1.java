package esbagno;


public class runnable1 implements Runnable 
{
    
    public void run()
    {
        
        bagno p1= new bagno();
        
        p1.stampaUomo();
    }
    
    
    
}
