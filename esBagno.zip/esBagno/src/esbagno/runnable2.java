package esbagno;


public class runnable2 implements Runnable {
    
    public void run(){
        
        bagno2 p2= new bagno2();
        
        p2.stampaDonna();
    }
    
    
}
